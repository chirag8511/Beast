import React from 'react';

function App() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h1>Beast Mode Dashboard</h1>
      <p>Let’s turn that 10k into 1L. Stay focused. Trade smart.</p>
    </div>
  );
}

export default App;